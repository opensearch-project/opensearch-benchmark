
echo "Converting selected XML attributes to CSV"
python ConvertStackDataToCsv.py 

echo "Sorting CSV into question ID order"
sort posts.csv > sortedposts.csv

echo "Converting sorted CSV into JSON (Question plus nested answers)"
python ConvertCSVToNestedJson.py >documents.json

bzip2 -9 -c documents.json > documents.json.bz2