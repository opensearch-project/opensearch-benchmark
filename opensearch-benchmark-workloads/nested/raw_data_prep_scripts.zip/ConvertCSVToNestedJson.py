import csv
import json



csvFilename="sortedposts.csv"

lastQ=None
answers=[]
tags=[]
date = None
acceptedAnswerId = None
title = None
acceptedAnswerer = None
asker=None
rowNum=0


with open(csvFilename, 'rb') as csvfile:
    csvreader = csv.reader(csvfile)
    for row in csvreader:
        rowNum+=1
        if rowNum==1:
            continue
        if len(row)<4:
            continue
        if row[0] != lastQ:
            if lastQ is not None:
                doc={
                    "qid":lastQ,
                    "title":title,
                    "creationDate":date,
                    "tag":tags,
                    "answers":answers,
                    "user":asker
                }
                if acceptedAnswerer is not None:
                    doc["answerer"]= acceptedAnswerer
                print(json.dumps(doc))

            lastQ=row[0]
            tags = row[2].split(",")
            answers=[]
            asker=row[3]
            date=row[4]
            acceptedAnswerId = row[5]
            title=row[6]
            acceptedAnswerer=None
        else:
            answers.append({
            "user" : row[3],
            "date" : row[4]
                    })
            if acceptedAnswerId == row[1]:
                acceptedAnswerer == row[3]


